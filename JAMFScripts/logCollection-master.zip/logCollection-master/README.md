<div align="center">

![alt text](https://kc9wwh-media.s3.us-east-2.amazonaws.com/logCollection/media/logCollection_Banner-sm.png "Icon made by iconixar from flaticon.com")

## Download Latest Version
[logCollection.sh](https://github.com/kc9wwh/logCollection/blob/master/logCollection.sh)

[logCollection.sh w/ EncryptedStrings built-in](https://github.com/kc9wwh/logCollection/blob/master/logCollection-encStrings.sh)

## Questions on Implementation?
Check out the [Wiki](https://github.com/kc9wwh/logCollection/wiki) for guides on how to setup and configure for your environment!

If you have issues after that, please open an [issue](https://github.com/kc9wwh/logCollection/issues/new/choose).

## Looking for a copy of the slides from vJNUC 2020?
[JNUC 2020 - Github Gallery - logCollection.key](https://github.com/kc9wwh/logCollection/blob/master/vJNUC2020/JNUC%202020%20-Github%20Gallery%20-%20logCollection.key)

[JNUC 2020 - Github Gallery - logCollection.pdf](https://github.com/kc9wwh/logCollection/blob/master/vJNUC2020/JNUC%202020%20-Github%20Gallery%20-%20logCollection.pdf)

</div>
